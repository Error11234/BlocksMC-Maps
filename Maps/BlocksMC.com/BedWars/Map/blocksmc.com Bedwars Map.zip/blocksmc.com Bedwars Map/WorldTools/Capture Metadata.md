# blocksmc.com Bedwars Map (blocksmc.com) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sun, 8 Jun 2025 12:16:59 +0200` (Timestamp: `1749377819525`)
- **Captured By**: `ErrorGHG`

## Server
- **IP**: `blocksmc.com`
- **Capacity**: `0/1`
- **Brand**: `FlameCord <- BlocksMC`
- **MOTD**: `                   --[ Invalid Server ]--          Protection by ⚡ Infinity-Filter.com ⚡ `
- **Version**: `Infinity-Filter.com`
- **Protocol Version**: `-1`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `ip24.ip-135-125-178.eu`
- **Port**: `25565`
- **Session ID**: `1186cad4-2417-480d-96ec-762049266136`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)

# BlocksMC.com TNTRun (blocksmc.com) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sun, 8 Jun 2025 12:32:49 +0200` (Timestamp: `1749378769151`)
- **Captured By**: `ErrorGHG`

## Server
- **IP**: `blocksmc.com`
- **Capacity**: `0/1`
- **Brand**: `FlameCord <- BlocksMC`
- **MOTD**: `                   --[ Invalid Server ]--          Protection by ⚡ Infinity-Filter.com ⚡ `
- **Version**: `Infinity-Filter.com`
- **Protocol Version**: `-1`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `ip56.ip-135-125-147.eu`
- **Port**: `25565`
- **Session ID**: `3301114d-d850-4e52-9b8f-e037b75611ae`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
